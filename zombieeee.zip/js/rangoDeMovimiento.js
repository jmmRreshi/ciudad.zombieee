var RangoDeMovimiento = function(desdeX, desdeY, hastaX, hastaY) {
	this.desdeX = desdeX;
	this.desdeY = desdeY;
	this.hastaX = hastaX;
	this.hastaY = hastaY;
}
